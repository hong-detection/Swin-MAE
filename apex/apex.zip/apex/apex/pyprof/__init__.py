import warnings

from . import nvtx, prof

warnings.warn("pyprof will be removed by the end of June, 2022", FutureWarning)
